## About this package

It contains a Controller meant solely to test the authorization of the roles

The controller is only loaded when the "test" profile is active, so it does not interfere with your real controllers

If you don't include the security tests in your project you can safely delete this package